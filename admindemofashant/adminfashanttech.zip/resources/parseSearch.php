<?php
/**
 * Created by PhpStorm.
 * User: isakl
 * Date: 23/08/2018
 * Time: 21:55
 */

//header('Content-Type: application/json');


echo '["<a href=\"list.php?f=&brands[]=Boston Celtics\">Boston Celtics</a>", "Chicago Bulls", "Miami Heat", "Orlando Magic", "Atlanta Hawks", "Philadelphia Sixers", "New York Knicks", "Indiana Pacers", "Charlotte Bobcats", "Milwaukee Bucks", "Detroit Pistons", "New Jersey Nets", "Toronto Raptors", "Washington Wizards", "Cleveland Cavaliers"]';

//echo '[{value:"Boston Celtics",label:"/list.php?f=&brands[]=Boston Celtics"}]';

//echo '[{ value: "Nike", label: "list.php?f=&brands[]=Nike" }, { value: "Adidas", label: "list.php?f=&brands[]=Adidas"}]';

//$data = array();
//$data['value'] = "Nike";
//$data['label'] = "list.php?f=&brands[]=Adidas";

//
//$data[] = array(
//    'value' => "Nike",
//    'label' => "list.php?f=&brands[]=Adidas"
//);
//
//echo json_encode($data);

// list.php?f=&brands[]=Boston%20Celtics


//echo "{'Nike':'list.php?f=Nike'}";

//echo "['<div><a href='list.php?f=&brands[]=Nike'>Nike</a></div>']";
//echo "['Nike']";


//echo '["<div><a href=\"\">Boston Celtics", "Chicago Bulls", "Miami Heat", "Orlando Magic", "Atlanta Hawks", "Philadelphia Sixers", "New York Knicks", "Indiana Pacers", "Charlotte Bobcats", "Milwaukee Bucks", "Detroit Pistons", "New Jersey Nets", "Toronto Raptors", "Washington Wizards", "Cleveland Cavaliers"]';

<?php
/**
 * Created by PhpStorm.
 * User: isakl
 * Date: 07/08/2018
 * Time: 14:16
 */

include_once 'resources/session.php';
include_once 'resources/utilities.php';

ob_start();
signout();
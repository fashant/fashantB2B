<?php
/**
 * Created by PhpStorm.
 * User: isakl
 * Date: 22/08/2018
 * Time: 16:42
 */

?>

<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<div class="clearfix"></div>
<!----header-start---->
<div class="navtop">
    <div class="container">
        <div class="topnav">
            <div class="col-sm-2">
                <div class="logodiv"> <a href="index.php"><img src="images/logo11.png"></a> </div>
            </div>
            <div class="col-sm-2">
                <div class="left_part">
                    <div class="social_icon">
                        <ul>
                            <li><a href="https://twitter.com/fashant_ae"><i class="flipt fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="https://www.facebook.com/Fashant"><i class="flipt fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href=""><i class="flipt fa fa-instagram" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="mid_part">
                    <div class="menu-fullm1">
                        <li class="downlod_app"><a href="marketplace.html">Explore Fashion</a></li>
                        <li class="services"><a href="http://fashant.com/FSBlogs/forums/">Fashion Advice</a></li>
                        <li class="notification"><a href="http://fashant.com/FSBlogs/">Latest Trends</a></li>
                        <li class="authorization-link sign_in"><a href="#"> Sign In </a></li>
                        <li class="sign_up"><a href="#">Sign up</a></li>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!----header-off------>
<div class="clearfix"></div>